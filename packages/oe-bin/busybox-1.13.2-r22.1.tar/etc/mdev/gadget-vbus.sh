#!/bin/sh

# Actions to perform when vbus changes state

unotify

if [ $ACTION = "add" ]; then
	# VBUS went HIGH; refresh IP address, start DFTP */
	logger -s -t 'vbus-actions' -p local4.notice 'VBUS went high; clear get-ip cache, refresh avahi-autoipd, start DFTP'
	# Clear get-ip cache
	rm -f /tmp/ip-host /tmp/ip-device
	avahi-autoipd --refresh usb0
	/etc/init.d/dftpdevice start
else
	# VBUS went LOW; stop dftp
	logger -s -t 'vbus-actions' -p local4.notice 'VBUS went low; stop DFTP'
	/etc/init.d/dftpdevice stop
fi

