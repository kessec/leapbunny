#!/bin/sh

if [ -e /tmp/cartridge ]; then
	cnotify
fi
