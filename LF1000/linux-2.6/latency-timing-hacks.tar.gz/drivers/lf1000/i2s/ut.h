//////////////////////////////////////////////////////////////////////////////
// UT Packets
//////////////////////////////////////////////////////////////////////////////
enum eCheckpoint_UT {
	kDMAAddEmpty_ut,
	kDMAAddSched_ut,
	kWriteAddSched_ut,
	kWriteAddFilled_ut,
	kWriteAudio_ut,
	kKernelKeyDown_ut,
	kKernelKeyUp_ut,
	kAudioOutputRetCB_ut,
	kMixerPaused_ut,
	kMixerRender_ut,
	kMemPlayerRendCBStart_ut,
	kMemPlayerRendCBDone_ut,
	kMemPlayerRendFileStart_ut,
	kMemPlayerRendFileDone_ut,
	kBrioAppButtonRecv_ut,
	kBrioAppStartSound_ut,
	kBrioAppStopSound_ut,
};

enum eType_UT {
	ktSound_ut,
	ktSilence_ut,
	ktButton_ut,
};

#define SEQ0_KERNEL_AUDIO_UT	0
#define SEQ0_BRIO_MIXER_UT	10000
#define SEQ0_KERNEL_KEY_UT	20000
#define SEQ0_BRIO_APP_UT	30000

#ifndef KERNEL_VERSION
typedef U32 u32;
typedef U16 u16;
typedef U8 u8;
#endif

struct sInfo_UT // 5*32 bits = 20 bytes (3*32 outside kernel)
{
	u32 id;  // some unique id of packet -- maybe checksum of first N words?
	u16 pad;
	u16 seq; // some incrementing sequence in case id is not unique
	u16 len; // length of packet - 0-4K
	u8 type; // Type - ogg sound or wav sound or silence or button
	u8 checkpoint; // where in the pipe it just passed
#ifdef KERNEL_VERSION
	struct timespec time;	// Only sysfs knows about time entry
#endif
};

#define sizeofUserInfo	(sizeof(struct sInfo_UT)-sizeof(struct timespec))

#ifdef KERNEL_VERSION
extern void ut_add_packet (u32 id, u16 pad, u16 seq, u16 len, u8 type, u8 checkpoint);
#else
#include <fcntl.h>
static void ut_add_packet (u32 id, u16 pad, u16 seq, u16 len, u8 type, u8 checkpoint)
{
	static int fid = -1;
	if (fid == -1)
	{
		fid = open ("/sys/devices/platform/lf1000-audio/ut", O_WRONLY);
		if (fid == -1)
			fid = open ("/sys/devices/platform/lf1000-audio/ut2", O_WRONLY);
		if (fid == -1)
			exit (1);
	}
	else
		lseek (fid, 0, 0);
	struct sInfo_UT h = { id, pad, seq, len, type, checkpoint };
	write (fid, &h, sizeof (struct sInfo_UT));
}
#endif

//////////////////////////////////////////////////////////////////////////////
// 103	KEY_UP	
// 108	KEY_DOWN	
// 106	KEY_RIGHT	
// 105	KEY_LEFT	
// 30	KEY_A	
// 48	KEY_B	
// 38	KEY_L	/* L 'shoulder' */
// 19	KEY_R	/* R 'shoulder' */
// 50	KEY_M	/* menu / home / start */
// 35	KEY_H	/* hint */
// 25	KEY_P	/* pause */
// 45	KEY_X	/* brightness */
// 16	BUTTON_VOLUMEUP	
// 17	BUTTON_VOLUMEDOWN	
